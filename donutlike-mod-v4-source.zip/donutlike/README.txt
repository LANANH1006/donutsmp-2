DonutLike v1.1 - Fabric 1.21.4 (Java 21 + Fabric Loader + Fabric API 0.119.2+1.21.4)

BUILD LOCAL: cai JDK 21 + Gradle 8.12, mo terminal trong thu muc nay: gradle build
             -> build/libs/donutlike-1.1.0.jar -> bo vao mods (cung Fabric API)
BUILD GITHUB: push len GitHub -> tab Actions -> "Build mod" -> tai artifact "donutlike-mod".
              Muon tao Release: git tag v1.1.0 && git push origin v1.1.0

MOI TRONG v1.1
- Can cu rai rac: moi o 176x176 block co ~60% co 1 can cu (go / gach da 2 tang / ham obsidian),
  ~50% da bi raid (tuong thung, ruong bi lay do, mang nhen, ho bom, vun). Xay khi ban den gan.
  /randombase [intact|raided] (op) de sinh thu ngay canh ban.
- Bang ben phai (sidebar) kieu DonutSMP cu: tien, shards, kills, deaths, playtime, online. /sidebar de bat/tat.
- /baltop /killtop /shardtop /playtop (co hang cua ban o cuoi).

LENH: go /donuthelp trong game.
Duel: /duel bot <noob|normal|pro|cpvp> [tien cuoc]
      /duel custom <mau> <sat thuong> <toc do 0.1-0.6> <giap 0-4> <totem> <crystal true/false>
      /duel leave
Chinh bot o Duels.java (SPECS). Tien/gia o DonutLike.java va bang PRICES.
Chinh can cu o Bases.java (CELL, BASE_CHANCE, loot). Chinh sidebar o Hud.java (buildLines).
