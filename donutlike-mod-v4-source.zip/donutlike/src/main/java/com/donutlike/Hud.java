package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.network.packet.s2c.play.ScoreboardDisplayS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardObjectiveUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardScoreResetS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardScoreUpdateS2CPacket;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.number.BlankNumberFormat;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.*;
import java.util.function.Function;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * Bang thong tin ben phai (sidebar) kieu DonutSMP cu + cac bang xep hang /baltop /killtop /shardtop /playtop.
 * Sidebar gui bang packet rieng cho tung nguoi choi (moi nguoi thay so lieu cua minh), khong dung scoreboard cua server.
 */
public class Hud {

    static final String TITLE = "§6§lDONUTLIKE";
    static final String FOOTER = "§edonutlike.local";
    static final int MAX_LINES = 12;

    static final ScoreboardObjective OBJ = new ScoreboardObjective(
            new Scoreboard(), "donutlike", ScoreboardCriterion.DUMMY, Text.literal(TITLE),
            ScoreboardCriterion.RenderType.INTEGER, true, BlankNumberFormat.INSTANCE);

    /** nguoi choi dang thay sidebar -> cac dong da gui lan truoc (de chi gui lai khi doi) */
    static final Map<UUID, List<String>> SHOWN = new HashMap<>();
    static final Set<UUID> HIDDEN = new HashSet<>();

    // ===== Sidebar =====
    static void everySecond(MinecraftServer s) {
        List<ServerPlayerEntity> ps = s.getPlayerManager().getPlayerList();
        // don nguoi da thoat
        Set<UUID> online = new HashSet<>();
        for (ServerPlayerEntity p : ps) online.add(p.getUuid());
        SHOWN.keySet().retainAll(online);

        for (ServerPlayerEntity p : ps) {
            UUID id = p.getUuid();
            boolean shown = SHOWN.containsKey(id);
            if (HIDDEN.contains(id)) {
                if (shown) { hide(p); SHOWN.remove(id); }
                continue;
            }
            List<String> lines = buildLines(s, p);
            if (!shown) {
                p.networkHandler.sendPacket(new ScoreboardObjectiveUpdateS2CPacket(OBJ, 0));
                p.networkHandler.sendPacket(new ScoreboardDisplayS2CPacket(ScoreboardDisplaySlot.SIDEBAR, OBJ));
            }
            List<String> old = SHOWN.get(id);
            for (int i = 0; i < lines.size(); i++) {
                if (old != null && i < old.size() && old.get(i).equals(lines.get(i))) continue;
                p.networkHandler.sendPacket(new ScoreboardScoreUpdateS2CPacket(
                        "l" + i, OBJ.getName(), lines.size() - i,
                        Optional.of(Text.literal(lines.get(i))), Optional.of(BlankNumberFormat.INSTANCE)));
            }
            SHOWN.put(id, lines);
        }
    }

    static void hide(ServerPlayerEntity p) {
        for (int i = 0; i < MAX_LINES; i++)
            p.networkHandler.sendPacket(new ScoreboardScoreResetS2CPacket("l" + i, OBJ.getName()));
        p.networkHandler.sendPacket(new ScoreboardObjectiveUpdateS2CPacket(OBJ, 1));
    }

    static List<String> buildLines(MinecraftServer s, ServerPlayerEntity p) {
        String id = p.getUuid().toString();
        DonutLike.Save sv = DonutLike.save;
        long secs = sv.playSecs.getOrDefault(id, 0L);
        List<String> l = new ArrayList<>();
        l.add("§7" + new java.text.SimpleDateFormat("dd/MM/yy").format(new Date()));
        l.add(" ");
        l.add("§a$ §fTiền: §a$" + shortNum(DonutLike.bal(p.getUuid())));
        l.add("§d* §fShards: §d" + sv.shards.getOrDefault(id, 0));
        l.add("§c+ §fKills: §c" + sv.kills.getOrDefault(id, 0));
        l.add("§4x §fDeaths: §4" + sv.deaths.getOrDefault(id, 0));
        l.add("§e> §fPlaytime: §e" + (secs / 3600) + "h " + ((secs % 3600) / 60) + "m");
        l.add("§b# §fOnline: §b" + s.getCurrentPlayerCount());
        l.add("  ");
        l.add(FOOTER);
        return l;
    }

    /** 1500 -> 1.5K, 2300000 -> 2.3M ... giong kieu hien so tien tren DonutSMP */
    static String shortNum(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        double a = v;
        while (Math.abs(a) >= 1000 && i < suf.length - 1) { a /= 1000; i++; }
        String s = i == 0 ? String.format("%.0f", a) : String.format("%.1f", a);
        if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
        return s + suf[i];
    }

    // ===== Lenh =====
    static void register(CommandDispatcher<ServerCommandSource> d) {
        // /sidebar - bat/tat bang ben phai
        d.register(literal("sidebar").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            boolean nowHidden = HIDDEN.add(p.getUuid());
            if (!nowHidden) HIDDEN.remove(p.getUuid());
            DonutLike.msg(p, nowHidden ? "§eĐã tắt bảng bên phải. Gõ /sidebar để bật lại." : "§aĐã bật bảng bên phải.");
            return 1;
        }));

        d.register(literal("baltop").executes(c ->
                top(c.getSource(), "Top Tiền", DonutLike.save.bal, v -> "§a$" + shortNum(v))));
        d.register(literal("killtop").executes(c ->
                top(c.getSource(), "Top Kills", DonutLike.save.kills, v -> "§c" + (long) (double) v)));
        d.register(literal("shardtop").executes(c ->
                top(c.getSource(), "Top Shards", DonutLike.save.shards, v -> "§d" + (long) (double) v)));
        d.register(literal("playtop").executes(c ->
                top(c.getSource(), "Top Thời gian chơi", DonutLike.save.playSecs,
                        v -> "§e" + ((long) (double) v / 3600) + "h " + (((long) (double) v % 3600) / 60) + "m")));
    }

    static int top(ServerCommandSource src, String title, Map<String, ? extends Number> map, Function<Double, String> f) {
        List<Map.Entry<String, ? extends Number>> l = new ArrayList<>(map.entrySet());
        l.sort((a, b) -> Double.compare(b.getValue().doubleValue(), a.getValue().doubleValue()));
        StringBuilder sb = new StringBuilder("§6§m    §r §e§l" + title + " §6§m    ");
        for (int i = 0; i < Math.min(10, l.size()); i++) {
            String key = l.get(i).getKey();
            String name = DonutLike.save.names.getOrDefault(key, key.length() > 8 ? key.substring(0, 8) : key);
            sb.append("\n§e#").append(i + 1).append(" §f").append(name)
              .append(" ").append(f.apply(l.get(i).getValue().doubleValue()));
        }
        ServerPlayerEntity me = src.getPlayer();
        if (me != null) {
            String mid = me.getUuid().toString();
            for (int i = 0; i < l.size(); i++) {
                if (l.get(i).getKey().equals(mid)) {
                    sb.append("\n§7Bạn: §f#").append(i + 1).append(" ").append(f.apply(l.get(i).getValue().doubleValue()));
                    break;
                }
            }
        }
        String out = sb.toString();
        src.sendFeedback(() -> Text.literal(out), false);
        return 1;
    }
}
