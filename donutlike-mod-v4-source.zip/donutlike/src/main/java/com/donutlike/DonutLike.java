package com.donutlike;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.command.argument.ItemStackArgumentType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class DonutLike implements ModInitializer {

    // ===== Cau hinh nhanh =====
    static final double START_MONEY = 1000;        // tien khoi dau
    static final int BASE_INTERVAL_SECONDS = 600;  // moi 10 phut tu sinh 1 can cu
    static final int NPC_LISTING_TARGET = 20;      // so mon NPC luon co tren /ah

    // ===== Du lieu =====
    static class Home { double x, y, z; String dim; }
    static class Save {
        Map<String, Double> bal = new HashMap<>();
        double[] spawn = null;
        Map<String, String> names = new HashMap<>();
        Map<String, Map<String, Home>> homes = new HashMap<>();
        Map<String, Integer> kills = new HashMap<>(), deaths = new HashMap<>(), shards = new HashMap<>(),
                duelWins = new HashMap<>(), duelLosses = new HashMap<>();
        Map<String, Long> playSecs = new HashMap<>(), lastDaily = new HashMap<>(), lastKit = new HashMap<>();
        Set<String> baseCells = new HashSet<>(); // o luoi can cu da xu ly
    }
    static class Listing {
        UUID seller; String sellerName; ItemStack stack; double price; long npcAt;
        Listing(UUID s, String n, ItemStack st, double p, long npcAt) { seller = s; sellerName = n; stack = st; price = p; this.npcAt = npcAt; }
    }
    static class Order {
        UUID buyer; ItemStack template; int amount; double perItem; long deliverAt;
        Order(UUID b, ItemStack t, int a, double p, long d) { buyer = b; template = t; amount = a; perItem = p; deliverAt = d; }
    }

    public static final List<Listing> LISTINGS = new ArrayList<>();
    static final List<Order> ORDERS = new ArrayList<>();
    static final Map<String, Double> PRICES = new LinkedHashMap<>();
    static final String[] NAMES = {"Alex_VN", "DonutKing", "xX_Miner_Xx", "Hana", "Bao123", "NoobMaster", "Lan_Anh", "Zephyr", "TanSMP", "Minh_PvP", "CrystalGod", "Linh"};
    static final Random R = new Random();
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    static Save save = new Save();
    static Path file;
    static MinecraftServer SERVER;
    static long tick = 0;

    static {
        PRICES.put("diamond", 100.0); PRICES.put("emerald", 40.0); PRICES.put("iron_ingot", 10.0);
        PRICES.put("gold_ingot", 15.0); PRICES.put("netherite_ingot", 800.0); PRICES.put("coal", 3.0);
        PRICES.put("copper_ingot", 4.0); PRICES.put("redstone", 3.0); PRICES.put("lapis_lazuli", 4.0);
        PRICES.put("oak_log", 2.0); PRICES.put("cobblestone", 0.5); PRICES.put("bread", 3.0);
        PRICES.put("golden_apple", 60.0); PRICES.put("ender_pearl", 25.0); PRICES.put("blaze_rod", 15.0);
        PRICES.put("obsidian", 8.0); PRICES.put("arrow", 1.0); PRICES.put("cooked_beef", 4.0);
        PRICES.put("diamond_sword", 250.0); PRICES.put("iron_sword", 40.0); PRICES.put("elytra", 3000.0);
    }

    @Override
    public void onInitialize() {
        file = FabricLoader.getInstance().getConfigDir().resolve("donutlike.json");
        load();
        if (save.baseCells == null) save.baseCells = new HashSet<>();
        Duels.init();

        ServerLifecycleEvents.SERVER_STARTED.register(s -> SERVER = s);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            Duels.endAll(s);
            // tra do dang ban cho nguoi choi online truoc khi tat may chu
            for (Listing l : LISTINGS) {
                if (l.seller == null) continue;
                ServerPlayerEntity p = s.getPlayerManager().getPlayer(l.seller);
                if (p != null) p.getInventory().offerOrDrop(l.stack);
            }
            LISTINGS.clear();
            doSave();
        });
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            tick++;
            Duels.tick(s);
            if (tick % 20 == 0) everySecond(s);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) -> {
            // /spawn
            dispatcher.register(CommandManager.literal("spawn").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                if (Duels.inDuel(p)) { msg(p, "§cKhông thể dùng lệnh này khi đang duel."); return 0; }
                ServerWorld w = ctx.getSource().getServer().getOverworld();
                double x, y, z;
                if (save.spawn != null) { x = save.spawn[0]; y = save.spawn[1]; z = save.spawn[2]; }
                else {
                    BlockPos sp = w.getSpawnPos();
                    x = sp.getX() + 0.5; z = sp.getZ() + 0.5;
                    y = w.getTopY(Heightmap.Type.MOTION_BLOCKING, sp.getX(), sp.getZ());
                }
                p.teleport(w, x, y, z, Set.of(), p.getYaw(), p.getPitch(), true);
                msg(p, "§aĐã dịch chuyển về spawn!");
                return 1;
            }));

            // /setspawn (op)
            dispatcher.register(CommandManager.literal("setspawn").requires(src -> src.hasPermissionLevel(2)).executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                save.spawn = new double[]{p.getX(), p.getY(), p.getZ()};
                doSave();
                msg(p, "§aĐã đặt spawn tại vị trí hiện tại.");
                return 1;
            }));

            // /bal
            dispatcher.register(CommandManager.literal("bal").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                msg(p, "§eSố dư: §a$" + fmt(bal(p.getUuid())));
                return 1;
            }));

            // /pay <player> <amount>
            dispatcher.register(CommandManager.literal("pay")
                .then(CommandManager.argument("player", EntityArgumentType.player())
                .then(CommandManager.argument("amount", DoubleArgumentType.doubleArg(0.01)).executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    ServerPlayerEntity t = EntityArgumentType.getPlayer(ctx, "player");
                    double a = DoubleArgumentType.getDouble(ctx, "amount");
                    if (bal(p.getUuid()) < a) { msg(p, "§cBạn không đủ tiền."); return 0; }
                    add(p.getUuid(), -a); add(t.getUuid(), a);
                    msg(p, "§aĐã chuyển $" + fmt(a) + " cho " + t.getName().getString());
                    msg(t, "§aBạn nhận được $" + fmt(a) + " từ " + p.getName().getString());
                    return 1;
                }))));

            // /sell <price>  - ban vat pham dang cam tren tay len /ah
            dispatcher.register(CommandManager.literal("sell")
                .then(CommandManager.argument("price", DoubleArgumentType.doubleArg(0.01)).executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    ItemStack hand = p.getMainHandStack();
                    if (hand.isEmpty()) { msg(p, "§cHãy cầm vật phẩm muốn bán trên tay."); return 0; }
                    double price = DoubleArgumentType.getDouble(ctx, "price");
                    long delay = 20L * (10 + R.nextInt(50)); // NPC xem xet mua sau 10-60 giay
                    LISTINGS.add(new Listing(p.getUuid(), p.getName().getString(), hand.copy(), price, tick + delay));
                    p.setStackInHand(Hand.MAIN_HAND, ItemStack.EMPTY);
                    msg(p, "§aĐã đăng bán lên /ah với giá $" + fmt(price) + ". Đang chờ người mua...");
                    return 1;
                })));

            // /ah
            dispatcher.register(CommandManager.literal("ah").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                AhHandler.open(p);
                return 1;
            }));

            // /order <item> <amount> <price_per_item>
            dispatcher.register(CommandManager.literal("order")
                .then(CommandManager.argument("item", ItemStackArgumentType.itemStack(registryAccess))
                .then(CommandManager.argument("amount", IntegerArgumentType.integer(1, 2304))
                .then(CommandManager.argument("price", DoubleArgumentType.doubleArg(0.01)).executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    ItemStack tpl = ItemStackArgumentType.getItemStackArgument(ctx, "item").createStack(1, false);
                    int amount = IntegerArgumentType.getInteger(ctx, "amount");
                    double per = DoubleArgumentType.getDouble(ctx, "price");
                    double total = per * amount;
                    if (bal(p.getUuid()) < total) { msg(p, "§cBạn cần $" + fmt(total) + " để đặt order này."); return 0; }
                    add(p.getUuid(), -total);
                    ORDERS.add(new Order(p.getUuid(), tpl, amount, per, tick + 20L * (10 + R.nextInt(50))));
                    msg(p, "§aĐã đặt order " + amount + "x " + tpl.getName().getString() + " ($" + fmt(per) + "/cái). Đang chờ người giao...");
                    return 1;
                })))));

            ExtraCommands.register(dispatcher);
            Hud.register(dispatcher);
            Duels.register(dispatcher);

            // /randombase [intact|raided] (op) - sinh 1 can cu gan ban
            dispatcher.register(CommandManager.literal("randombase").requires(src -> src.hasPermissionLevel(2))
                .executes(ctx -> runRandomBase(ctx.getSource(), null))
                .then(CommandManager.literal("intact").executes(ctx -> runRandomBase(ctx.getSource(), false)))
                .then(CommandManager.literal("raided").executes(ctx -> runRandomBase(ctx.getSource(), true))));
        });
    }

    static int runRandomBase(net.minecraft.server.command.ServerCommandSource src, Boolean raided) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity p = src.getPlayerOrThrow();
        Bases.Result r = Bases.spawnNear(src.getServer().getOverworld(), p.getBlockPos(), 40, 80, raided);
        if (r == null) { msg(p, "§cKhông tìm được chỗ đặt căn cứ, thử lại."); return 0; }
        msg(p, "§6Căn cứ " + r.style() + (r.raided() ? " (đã bị raid)" : " (còn nguyên)") + " tại "
                + r.pos().getX() + " " + r.pos().getY() + " " + r.pos().getZ());
        return 1;
    }

    // ===== Vong lap moi giay =====
    static void everySecond(MinecraftServer s) {
        ExtraCommands.everySecond(s);
        Hud.everySecond(s);
        if (tick % 40 == 0) Bases.scatterTick(s);
        // NPC mua do trong /ah
        Iterator<Listing> it = LISTINGS.iterator();
        while (it.hasNext()) {
            Listing l = it.next();
            if (l.seller == null || l.npcAt <= 0 || tick < l.npcAt) continue;
            double v = value(l.stack.getItem()) * l.stack.getCount();
            if (l.price <= v * 1.5) {
                it.remove();
                add(l.seller, l.price);
                ServerPlayerEntity p = s.getPlayerManager().getPlayer(l.seller);
                if (p != null) msg(p, "§a[AH] " + NAMES[R.nextInt(NAMES.length)] + " đã mua " + l.stack.getCount() + "x "
                        + l.stack.getName().getString() + " với giá $" + fmt(l.price));
            } else {
                l.npcAt = -1; // gia qua cao: de cho nguoi choi that mua
            }
        }

        // NPC giao hang cho order
        Iterator<Order> oi = ORDERS.iterator();
        while (oi.hasNext()) {
            Order o = oi.next();
            if (tick < o.deliverAt) continue;
            oi.remove();
            ServerPlayerEntity p = s.getPlayerManager().getPlayer(o.buyer);
            double total = o.perItem * o.amount;
            if (p == null || o.perItem < value(o.template.getItem()) * 0.7) {
                add(o.buyer, total); // hoan tien
                if (p != null) msg(p, "§c[Order] Giá quá thấp, không ai giao. Đã hoàn $" + fmt(total));
                continue;
            }
            int left = o.amount;
            while (left > 0) {
                int n = Math.min(o.template.getMaxCount(), left);
                p.getInventory().offerOrDrop(o.template.copyWithCount(n));
                left -= n;
            }
            msg(p, "§a[Order] " + NAMES[R.nextInt(NAMES.length)] + " đã giao " + o.amount + "x " + o.template.getName().getString());
        }

        // NPC dang ban de /ah luon co hang
        if (tick % (20 * 30) == 0) {
            long npc = LISTINGS.stream().filter(l -> l.seller == null).count();
            for (int i = 0; i < 2 && npc < NPC_LISTING_TARGET; i++, npc++) addNpcListing();
        }

        // sinh can cu ngau nhien
        if (tick % (20L * BASE_INTERVAL_SECONDS) == 0) {
            List<ServerPlayerEntity> ps = s.getPlayerManager().getPlayerList();
            if (!ps.isEmpty()) {
                ServerPlayerEntity p = ps.get(R.nextInt(ps.size()));
                if (spawnBaseNear(s.getOverworld(), p.getBlockPos(), 150, 400) != null)
                    for (ServerPlayerEntity q : ps) msg(q, "§6Một căn cứ mới vừa xuất hiện đâu đó trong thế giới...");
            }
        }

        if (tick % (20 * 300) == 0) doSave();
    }

    static void addNpcListing() {
        List<String> keys = new ArrayList<>(PRICES.keySet());
        String id = keys.get(R.nextInt(keys.size()));
        Item item = Registries.ITEM.get(Identifier.of("minecraft", id));
        int max = Math.min(item.getMaxCount(), 32);
        int count = 1 + R.nextInt(Math.max(1, max));
        double price = PRICES.get(id) * count * (0.8 + R.nextDouble() * 0.8);
        LISTINGS.add(new Listing(null, NAMES[R.nextInt(NAMES.length)], new ItemStack(item, count), Math.round(price * 100) / 100.0, -1));
    }

    // ===== Can cu ngau nhien (xem Bases.java) =====
    static BlockPos spawnBaseNear(ServerWorld w, BlockPos origin, int minD, int maxD) {
        Bases.Result r = Bases.spawnNear(w, origin, minD, maxD, null);
        return r == null ? null : r.pos();
    }

    static void set(ServerWorld w, BlockPos p, Block b) { w.setBlockState(p, b.getDefaultState(), Block.NOTIFY_LISTENERS); }

    // ===== Tien & tien ich =====
    public static double bal(UUID id) { return save.bal.getOrDefault(id.toString(), START_MONEY); }
    public static void add(UUID id, double a) { save.bal.put(id.toString(), bal(id) + a); }
    public static double value(Item i) { return PRICES.getOrDefault(Registries.ITEM.getId(i).getPath(), 2.0); }
    public static String fmt(double d) { return String.format("%.2f", d); }
    public static void msg(ServerPlayerEntity p, String s) { p.sendMessage(Text.literal(s), false); }

    static void load() {
        try { if (Files.exists(file)) { Save s = GSON.fromJson(Files.readString(file), Save.class); if (s != null) save = s; } }
        catch (Exception e) { e.printStackTrace(); }
    }
    static void doSave() {
        try { Files.writeString(file, GSON.toJson(save)); } catch (Exception e) { e.printStackTrace(); }
    }
}
